package page_objects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LandingPage {

    @FindBy(xpath="//header[@class='container-header']")
    private WebElement header;

    @FindBy(xpath="//button[@class='container-header__button container-header__button__enter']")
    private WebElement enterButton;



}
