package step_definitions;

import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.pt.*;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;

public class AutenticacaoSteps {

    private WebDriver driver = new ChromeDriver();

    @After("@autenticacao")
    public void afterScenario(Scenario scenario) throws IOException {

        if (scenario.isFailed()) {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File("C:\\Users\\cwg0660\\Downloads\\screenshot.png"));
        }
    }

    @After("@autenticacao")
    public void closeBrowser() {
        if(driver!=null) {
            driver.quit();
        }
    }

    @Dado("^que eu esteja navegando no Serasa Linha$")
    public void queEuEstejaNavegandoNoSerasaLinha() {
        driver.manage().window().maximize();
        driver.get("https://sme-credit-reports-frontend-sme-staging.apps.appcanvas.net/landing");
    }

    @Quando("^eu visualizo o header do site$")
    public void euVisualizoOHeaderDoSite() {
        driver.findElement(By.xpath("//header[@class='container-header']"));
    }

    @Quando("^eu aciono o botão Entrar no header do site$")
    public void euAcionoOBotãoEntrarNoHeaderDoSite() {
        driver.findElement(By.xpath("//button[@class='container-header__button container-header__button__enter']")).click();
    }

    @Então("^eu devo ver o botão entrar$")
    public void euDevoVerOBotãoEntrar() {
        driver.findElement(By.xpath("//button[@class='container-header__button container-header__button__enter']"));
    }

    @Então("^eu devo ver um modal com o \"([^\"]*)\"$")
    public void euDevoVerUmModalComO(String arg0) {
        driver.findElement(By.id("username"));
        driver.findElement(By.id("password"));
        driver.findElement(By.xpath("//i[@class='fa fa-lg fa-eye']"));
        driver.findElement(By.xpath("//div[@class='modal-login__container__body__lostPassword']"));
        driver.findElement(By.xpath("//button[@type='submit']"));
        driver.findElement(By.xpath("//a[@aria-label='Close']//i[@aria-hidden='true']"));
    }

    @Dado("^que eu acionei o botão Entrar no Serasa Linha$")
    public void queEuAcioneiOBotãoEntrarNoSerasaLinha() {
        driver.manage().window().maximize();
        driver.get("https://sme-credit-reports-frontend-sme-staging.apps.appcanvas.net/landing");
        driver.findElement(By.xpath("//button[@class='container-header__button container-header__button__enter']")).click();
    }

    @Quando("^eu aciono o ícone de visualização de senha no modal$")
    public void euAcionoOÍconeDeVisualizaçãoDeSenhaNoModal() {
        driver.findElement(By.id("password")).sendKeys("Teste123");
        driver.findElement(By.xpath("//i[@class='fa fa-lg fa-eye']")).click();
    }

    @Então("^eu devo ver os caracteres que forem digitados nesse campo$")
    public void euDevoVerOsCaracteresQueForemDigitadosNesseCampo() throws IOException {
        driver.findElement(By.xpath("//i[@class='fa fa-lg fa-eye']")).click();
        WebElement TxtBoxContent = driver.findElement(By.id("password"));
        System.out.println(TxtBoxContent.getAttribute("value"));
        Assert.assertEquals("Teste123", TxtBoxContent.getAttribute("value"));
    }


    @Quando("^eu aciono o link Esqueci minha senha no modal$")
    public void euAcionoOLinkEsqueciMinhaSenhaNoModal() throws Throwable {
        driver.findElement(By.xpath("//div[@class='modal-login__container__body__lostPassword']")).click();
    }

    @Então("^eu devo ver um modal onde digite o e-mail do cadastro$")
    public void euDevoVerUmModalOndeDigiteOEMailDoCadastro() throws Throwable {
        driver.findElement(By.xpath("//div[@class='modal-content']//app-forgot-password")).isDisplayed();
        driver.findElement(By.id("forgotPassword")).sendKeys("wknakamura+52@gmail.com");
    }

    @E("^receba um e-mail contendo o link para registro de nova senha$")
    public void recebaUmEMailContendoOLinkParaRegistroDeNovaSenha() throws Throwable {
        //driver.findElement(By.xpath("//button[@type='submit']")).click();
    }

    @Quando("^eu utilizo um usuário \"([^\"]*)\" no modal$")
    public void euUtilizoUmUsuárioNoModal(String arg0) throws Throwable {
        driver.findElement(By.id("username")).sendKeys(arg0);
    }

    @E("^uma senha \"([^\"]*)\"$")
    public void umaSenha(String arg0) throws Throwable {
        driver.findElement(By.id("password")).sendKeys(arg0);
    }

    @E("^aciono o botão Acessar$")
    public void acionoOBotãoAcessar() throws Throwable {
        driver.findElement(By.xpath("//button[@type='submit']")).click();
    }

    @Então("^eu devo ver a mensagem \"([^\"]*)\"$")
    public void euDevoVerAMensagem(String arg0) throws Throwable {
        //Assert.assertEquals(arg 0, texto.getResult());
    }

    @Quando("^eu preencho o campo usuário corretamente no modal$")
    public void euPreenchoOCampoUsuárioCorretamenteNoModal() throws Throwable {
        driver.findElement(By.id("username")).sendKeys("wknakamura+52@gmail.com");
    }

    @E("^o campo de senha também corretamente$")
    public void oCampoDeSenhaTambémCorretamente() throws Throwable {
        driver.findElement(By.id("password")).sendKeys("Serasa@0");
    }

    @Então("^eu devo ser direcionado para a área logada$")
    public void euDevoSerDirecionadoParaAÁreaLogada() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    }

    @Mas("^o serviço retorne algo diferente de sucesso/ insucesso$")
    public void oServiçoRetorneAlgoDiferenteDeSucessoInsucesso() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    }

    @Então("^eu devo ver a mensagem de alerta Ops! Serviço indisponível no momento\. Tente novamente mais tarde\.$")
    public void euDevoVerAMensagemDeAlertaOpsServiçoIndisponívelNoMomentoTenteNovamenteMaisTarde() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }
}



