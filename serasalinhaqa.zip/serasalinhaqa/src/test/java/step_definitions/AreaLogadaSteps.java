package step_definitions;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.Então;
import cucumber.api.java.pt.Quando;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;


//import cucumber.api.cli.Main.*

public class AreaLogadaSteps {

    private WebDriver driver = new ChromeDriver();

    @After("@arealogada")
    public void afterScenario(Scenario scenario) throws IOException {

        if (scenario.isFailed()) {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File("C:\\Users\\cwg0660\\Downloads\\screenshot.png"));
        }
    }

    @After("@arealogada")
    public void closeBrowser() {
        if(driver!=null) {
            driver.quit();
        }
    }

    @Dado("^que eu esteja na área logada no período da manhã$")
    public void queEuEstejaNaÁreaLogadaNoPeríodoDaManhã() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.manage().window().maximize();
        driver.get("https://sme-credit-reports-frontend-sme-staging.apps.appcanvas.net/landing");
        driver.findElement(By.xpath("//button[@class='container-header__button container-header__button__enter']")).click();
        driver.findElement(By.id("username")).sendKeys("wknakamura+52@gmail.com");
        driver.findElement(By.id("password")).sendKeys("Serasa@0");
        //driver.findElement(By.xpath("//button[@type='submit']")).isDisplayed();
        driver.findElement(By.xpath("//button[@type='submit']")).click();
    }

    @Quando("^eu observo o cabeçalho$")
    public void euObservoOCabeçalho() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Então("^eu devo ver a mensagem de Bom dia$")
    public void euDevoVerAMensagemDeBomDia() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }
}
