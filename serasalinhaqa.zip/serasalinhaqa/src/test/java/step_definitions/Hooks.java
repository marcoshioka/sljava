package step_definitions;

import cucumber.api.java.Before;
import org.openqa.selenium.WebDriver;

public class Hooks {



    private WebDriver driver;

    //public void getdriver() {
      //      private WebDriver driver = new WebDriver();
       // }


    @Before("@autenticacao, @arealogada")
    public void beforeScenario () {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\cwg0660\\Downloads\\chromedriver.exe");
     }

    /*@After("@autenticacao")
    public void afterScenario (){
              driver.quit();
    }*/



    /*@After("@botaoentrar, @modalautenticacao, @visualsenha")
    public void afterScenario(Scenario scenario) throws IOException {
        //System.out.println("\n--- Scenario " + scenario.getName() + " executed ---");

        if (scenario.isFailed()) {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File("C:\\Users\\cwg0660\\Downloads\\screenshot.png"));
        }*/

}
