@RunWith(Cucumber.class)

@CucumberOptions(  monochrome = true,
        tags = "@tags",
        features = "src/test/resources",
        format = { "pretty","html: cucumber-html-reports",
                "json: cucumber-html-reports/cucumber.json" },
        dryRun = false,
        glue = "step_definitions",
        plugin = { "pretty", "html:target/cucumber-reports"},
        monochrome = true)

public class TestRunner {
    //Run this
}